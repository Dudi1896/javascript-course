"use strict";
/*    JavaScript 7th Edition
      Chapter 12
      

      Project to convert between celsius and fahrenheit
      Author: 
      Date:   

     
*/

