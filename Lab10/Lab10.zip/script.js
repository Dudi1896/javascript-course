"use strict";
/*  JavaScript 7th Edition
    Chapter 10
   

    Driving Directions
    Author: 
    Date:   

   
*/


function showMap() {
   
   // Page objects
   let driveMap = document.getElementById("driveMap");
   let driveDirections = document.getElementById("driveDirections");
   let startingCity = document.getElementById("startingCity");
   let endingCity = document.getElementById("endingCity");   


} 


