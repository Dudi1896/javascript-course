"use strict";
/*    JavaScript 7th Edition
      Chapter 11
      

      Project to city and state information from a provided postal code
      Author: 
      Date:   

      
*/

let postalCode = document.getElementById("postalCode");
let place = document.getElementById("place");
let region = document.getElementById("region");
let country = document.getElementById("country");

postalCode.onblur = function() {
 
}



